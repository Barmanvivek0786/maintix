MAINTIX APP ICONS - GitHub par kaha upload karna hai
========================================================

VERSION CODE already GitHub par update ho chuka hai (1.0.0+31 -> 1.0.0+32)
Sirf ye icon files manually upload karni hain (GitHub web se drag-drop karo).

ANDROID (repo: android/app/src/main/res/ ke andar):
----------------------------------------------------
android/mipmap-ldpi/ic_launcher.png       -> android/app/src/main/res/mipmap-ldpi/ic_launcher.png
android/mipmap-mdpi/ic_launcher.png       -> android/app/src/main/res/mipmap-mdpi/ic_launcher.png
android/mipmap-hdpi/ic_launcher.png       -> android/app/src/main/res/mipmap-hdpi/ic_launcher.png
android/mipmap-xhdpi/ic_launcher.png      -> android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
android/mipmap-xxhdpi/ic_launcher.png     -> android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
android/mipmap-xxxhdpi/ic_launcher.png    -> android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
android/mipmap-anydpi-v26/ic_launcher.png -> android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.png

Google Play Console listing ke liye (app store page par dikhne wala icon):
android/PlayStore-512.png -> Play Console > Store presence > Main store listing > App icon (512x512 upload karo)

IOS (repo: ios/Runner/Assets.xcassets/AppIcon.appiconset/ ke andar):
----------------------------------------------------
ios/ folder ki saari 15 files -> ios/Runner/Assets.xcassets/AppIcon.appiconset/
(filenames already exact match hain existing files ke, bas overwrite/replace karna hai)

KAISE UPLOAD KARO (GitHub website se, mobile browser mein bhi chalega):
----------------------------------------------------
1. github.com/Barmanvivek0786/maintix kholo
2. Us folder mein jao jaha file daalni hai (e.g. android/app/src/main/res/mipmap-xxxhdpi)
3. "Add file" -> "Upload files" dabao
4. Isi naam ki file (ic_launcher.png) select karo -> ye automatically replace kar degi purani wali ko
5. Neeche "Commit changes" dabao
6. Har folder ke liye ye repeat karo

Note: AdaptiveIcon-Foreground-432.png bhi diya hai (transparent version) agar future mein 
proper Android Adaptive Icon (background+foreground layers) setup karna ho.
